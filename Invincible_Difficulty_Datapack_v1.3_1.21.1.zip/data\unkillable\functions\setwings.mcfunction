execute store result score @s cur_slot run data get entity @s SelectedItemSlot
scoreboard players operation @s cur_slot -= @s last_slot
execute unless score @s cur_slot matches 0 run clear @s minecraft:iron_nugget[custom_model_data=10]
execute store result score @s last_slot run data get entity @s SelectedItemSlot

execute unless entity @s[nbt={Inventory:[{slot:-106}]}] run item replace entity @s weapon.offhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:0}] unless entity @s[nbt={Inventory:[{slot:0}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:1}] unless entity @s[nbt={Inventory:[{slot:1}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:2}] unless entity @s[nbt={Inventory:[{slot:2}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:3}] unless entity @s[nbt={Inventory:[{slot:3}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:4}] unless entity @s[nbt={Inventory:[{slot:4}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:5}] unless entity @s[nbt={Inventory:[{slot:5}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:6}] unless entity @s[nbt={Inventory:[{slot:6}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:7}] unless entity @s[nbt={Inventory:[{slot:7}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
execute if entity @s[nbt={SelectedItemSlot:8}] unless entity @s[nbt={Inventory:[{slot:8}]}] run item replace entity @s weapon.mainhand with iron_nugget[custom_name='{"text":"Water Wing","italic":false}',custom_model_data=10]
