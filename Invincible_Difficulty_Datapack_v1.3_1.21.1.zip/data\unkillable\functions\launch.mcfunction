scoreboard players add @s launchTimer 1
effect give @s[scores={launchTimer=2}] levitation 1 80 true
effect clear @s[scores={launchTimer=8..}] levitation
scoreboard players set @s[scores={launchTimer=8..}] launchTimer 0
particle cloud ~ ~2 ~ 0 0 0 0.1 1 force
