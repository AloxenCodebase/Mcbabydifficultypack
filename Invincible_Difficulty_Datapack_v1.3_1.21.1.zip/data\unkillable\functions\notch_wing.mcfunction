scoreboard players add @s notch_timer 1
item replace entity @s[scores={notch_timer=2}] weapon.mainhand with air
item replace entity @s[scores={notch_timer=2}] armor.head with minecraft:carrot_on_a_stick[custom_model_data=1]
effect give @s[scores={notch_timer=2..5}] levitation 1 40 true
effect clear @s[scores={notch_timer=20}] levitation
effect give @s[scores={notch_timer=30}] levitation 1 170 true
effect clear @s[scores={notch_timer=35}] levitation
item replace entity @s[scores={notch_timer=35}] armor.head with air
scoreboard players set @s[scores={notch_timer=100..}] notch_timer 0


execute if entity @s[scores={notch_timer=3..25}] run particle cloud ~ ~2 ~ 0 0 0 0.1 2 force
execute if entity @s[scores={notch_timer=3..20}] run particle large_smoke ~ ~2.2 ~ 0 0 0 0.1 2 force


execute if entity @s[scores={notch_timer=2}] run playsound minecraft:entity.phantom.flap master @a ~ ~ ~ 10.0 1.0
execute if entity @s[scores={notch_timer=35}] run playsound minecraft:entity.iron_golem.damage master @a ~ ~ ~ 0.8 1.0
