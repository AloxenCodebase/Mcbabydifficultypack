function unkillable:entitytype
schedule function unkillable:slow_tick 1s
