give @s pink_bed
item replace entity @s weapon.mainhand with air
