give @s white_bed
item replace entity @s weapon.mainhand with air
