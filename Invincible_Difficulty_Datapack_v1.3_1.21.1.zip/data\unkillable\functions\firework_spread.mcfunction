execute at @s run particle portal ~ ~ ~ 0.5 0.5 0.5 0.1 30 force
summon armor_stand ~ ~ ~ {Tags:["fw_spreader"],Invisible:1,Marker:1}
spreadplayers ~ ~ 10 15 false @e[tag=fw_spreader]
execute as @s at @s run spreadplayers ~ ~ 10 15 false @e[tag=fw_spreader,distance=..5]
execute at @e[tag=fw_spreader,limit=1,sort=nearest] run tp @s ~ ~ ~
kill @e[tag=fw_spreader]
execute at @s run playsound minecraft:entity.enderman.teleport master @a
execute at @s run particle portal ~ ~ ~ 0.5 0.5 0.5 0.1 30 force
