data merge entity @s {Fire:-1s}
execute as @s[tag=cp1,nbt={OnGround:1b}] at @s run particle block glass ~ ~0.4 ~ 0.2 0.1 0.2 0.1 20 force
execute as @s[tag=cp2,nbt={OnGround:1b}] at @s run particle block purple_concrete_powder ~ ~0.4 ~ 0.2 0.1 0.2 0.1 5 force
kill @s[nbt={OnGround:1b}]
