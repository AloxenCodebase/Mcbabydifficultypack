give @s light_gray_bed
item replace entity @s weapon.mainhand with air
