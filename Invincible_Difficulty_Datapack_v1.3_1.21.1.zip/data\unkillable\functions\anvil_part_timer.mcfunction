scoreboard players add @s anvil_timer 1
kill @s[scores={anvil_timer=150..}]
execute as @s[tag=as_part1,tag=anvil_x,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[0.1,0.1,0.1]}
execute as @s[tag=as_part2,tag=anvil_x,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[-0.15,0.1,0.05]}
execute as @s[tag=as_part3,tag=anvil_x,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[-0.05,0.1,-0.05]}
execute as @s[tag=as_part4,tag=anvil_x,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[0.2,0.1,-0.1]}

execute as @s[tag=as_part1,tag=anvil_z,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[-0.1,0.1,0.1]}
execute as @s[tag=as_part2,tag=anvil_z,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[-0.15,0.1,-0.05]}
execute as @s[tag=as_part3,tag=anvil_z,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[0.05,0.1,-0.05]}
execute as @s[tag=as_part4,tag=anvil_z,scores={anvil_timer=2}] at @s run data merge entity @s {Motion:[0.1,0.1,0.2]}


execute as @s[tag=as_part1,scores={anvil_timer=3}] at @s run data merge entity @s {Pose:{Head:[4f,0f,4f]}}
execute as @s[tag=as_part1,scores={anvil_timer=4}] at @s run data merge entity @s {Pose:{Head:[8f,0f,8f]}}
execute as @s[tag=as_part1,scores={anvil_timer=5}] at @s run data merge entity @s {Pose:{Head:[11f,0f,11f]}}
execute as @s[tag=as_part1,scores={anvil_timer=6}] at @s run data merge entity @s {Pose:{Head:[13f,0f,13f]}}
execute as @s[tag=as_part1,scores={anvil_timer=7}] at @s run data merge entity @s {Pose:{Head:[15f,0f,15f]}}
execute as @s[tag=as_part1,scores={anvil_timer=8}] at @s run data merge entity @s {Pose:{Head:[17f,0f,17f]}}
execute as @s[tag=as_part1,scores={anvil_timer=9}] at @s run data merge entity @s {Pose:{Head:[19f,0f,19f]}}
execute as @s[tag=as_part1,scores={anvil_timer=10}] at @s run data merge entity @s {Pose:{Head:[21f,0f,21f]}}
execute as @s[tag=as_part1,scores={anvil_timer=11}] at @s run data merge entity @s {Pose:{Head:[23f,0f,23f]}}
execute as @s[tag=as_part1,scores={anvil_timer=12}] at @s run data merge entity @s {Pose:{Head:[25f,0f,25f]}}

execute as @s[tag=as_part2,scores={anvil_timer=3}] at @s run data merge entity @s {Pose:{Head:[0f,-3f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=4}] at @s run data merge entity @s {Pose:{Head:[0f,-5f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=5}] at @s run data merge entity @s {Pose:{Head:[0f,-7f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=6}] at @s run data merge entity @s {Pose:{Head:[0f,-9f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=7}] at @s run data merge entity @s {Pose:{Head:[0f,-11f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=8}] at @s run data merge entity @s {Pose:{Head:[0f,-13f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=9}] at @s run data merge entity @s {Pose:{Head:[0f,-14f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=10}] at @s run data merge entity @s {Pose:{Head:[0f,-15f,0f]}}
execute as @s[tag=as_part2,scores={anvil_timer=11}] at @s run data merge entity @s {Pose:{Head:[0f,-16f,0f]}}

execute as @s[tag=as_part3,scores={anvil_timer=3}] at @s run data merge entity @s {Pose:{Head:[-2f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=4}] at @s run data merge entity @s {Pose:{Head:[-4f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=5}] at @s run data merge entity @s {Pose:{Head:[-6f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=6}] at @s run data merge entity @s {Pose:{Head:[-8f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=7}] at @s run data merge entity @s {Pose:{Head:[-10f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=8}] at @s run data merge entity @s {Pose:{Head:[-12f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=9}] at @s run data merge entity @s {Pose:{Head:[-14f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=10}] at @s run data merge entity @s {Pose:{Head:[-16f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=11}] at @s run data merge entity @s {Pose:{Head:[-17f,0f,0f]}}
execute as @s[tag=as_part3,scores={anvil_timer=12}] at @s run data merge entity @s {Pose:{Head:[-18f,0f,0f]}}

execute as @s[tag=as_part4,scores={anvil_timer=3}] at @s run data merge entity @s {Pose:{Head:[0f,0f,5f]}}
execute as @s[tag=as_part4,scores={anvil_timer=4}] at @s run data merge entity @s {Pose:{Head:[0f,0f,9f]}}
execute as @s[tag=as_part4,scores={anvil_timer=5}] at @s run data merge entity @s {Pose:{Head:[0f,0f,13f]}}
execute as @s[tag=as_part4,scores={anvil_timer=6}] at @s run data merge entity @s {Pose:{Head:[0f,0f,17f]}}
execute as @s[tag=as_part4,scores={anvil_timer=7}] at @s run data merge entity @s {Pose:{Head:[0f,0f,22f]}}
execute as @s[tag=as_part4,scores={anvil_timer=8}] at @s run data merge entity @s {Pose:{Head:[0f,0f,25f]}}
execute as @s[tag=as_part4,scores={anvil_timer=9}] at @s run data merge entity @s {Pose:{Head:[1f,0f,28f]}}
execute as @s[tag=as_part4,scores={anvil_timer=10}] at @s run data merge entity @s {Pose:{Head:[2f,0f,31f]}}
execute as @s[tag=as_part4,scores={anvil_timer=11}] at @s run data merge entity @s {Pose:{Head:[3f,0f,34f]}}
execute as @s[tag=as_part4,scores={anvil_timer=12}] at @s run data merge entity @s {Pose:{Head:[4f,0f,37f]}}
execute as @s[tag=as_part4,scores={anvil_timer=13}] at @s run data merge entity @s {Pose:{Head:[5f,0f,40f]}}


kill @s[scores={anvil_timer=39}]
scoreboard players set @s[nbt={OnGround:1b},scores={anvil_timer=..39}] anvil_timer 40
execute as @s[scores={anvil_timer=40}] at @s run data merge entity @s {NoGravity:1}
execute as @s[tag=as_part1,scores={anvil_timer=40..45}] at @s run tp @s ~ ~-0.1 ~
execute as @s[tag=as_part4,scores={anvil_timer=40..43}] at @s run tp @s ~ ~-0.05 ~
