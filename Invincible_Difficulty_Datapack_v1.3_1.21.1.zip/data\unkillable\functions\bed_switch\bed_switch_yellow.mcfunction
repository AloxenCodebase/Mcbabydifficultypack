give @s yellow_bed
item replace entity @s weapon.mainhand with air
