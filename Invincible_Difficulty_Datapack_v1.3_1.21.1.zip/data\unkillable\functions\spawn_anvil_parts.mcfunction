tag @s[nbt={BlockState:{Properties:{facing:"south"}}}] add anvil_x
tag @s[nbt={BlockState:{Properties:{facing:"north"}}}] add anvil_x
tag @s[nbt={BlockState:{Properties:{facing:"east"}}}] add anvil_z
tag @s[nbt={BlockState:{Properties:{facing:"west"}}}] add anvil_z

playsound minecraft:entity.turtle.egg_crack master @a ~ ~ ~ 0.3 0.7
playsound minecraft:block.glass.break master @a ~ ~ ~ 0.2 0.8

particle smoke ~ ~0.5 ~ 0.2 0.2 0.2 0.1 30 force

summon armor_stand ~ ~ ~ {NoGravity:1,Tags:["as_center"],Invisible:1,DisabledSlots:4144959}

execute if entity @s[tag=anvil_x] run summon armor_stand ~ ~ ~ {Tags:["as_part1","anvil_part","anvil_x"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":20}}],Invisible:1,DisabledSlots:4144959}
execute if entity @s[tag=anvil_x] run summon armor_stand ~ ~ ~ {Tags:["as_part2","anvil_part","anvil_x"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":21}}],Invisible:1,DisabledSlots:4144959}
execute if entity @s[tag=anvil_x] run summon armor_stand ~ ~ ~ {Tags:["as_part3","anvil_part","anvil_x"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":22}}],Invisible:1,DisabledSlots:4144959}
execute if entity @s[tag=anvil_x] run summon armor_stand ~ ~ ~ {Tags:["as_part4","anvil_part","anvil_x"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":23}}],Invisible:1,DisabledSlots:4144959}

execute if entity @s[tag=anvil_z] run summon armor_stand ~ ~ ~ {Tags:["as_part1","anvil_part","anvil_z"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":20}}],Invisible:1,DisabledSlots:4144959,Rotation:[90f]}
execute if entity @s[tag=anvil_z] run summon armor_stand ~ ~ ~ {Tags:["as_part2","anvil_part","anvil_z"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":21}}],Invisible:1,DisabledSlots:4144959,Rotation:[90f]}
execute if entity @s[tag=anvil_z] run summon armor_stand ~ ~ ~ {Tags:["as_part3","anvil_part","anvil_z"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":22}}],Invisible:1,DisabledSlots:4144959,Rotation:[90f]}
execute if entity @s[tag=anvil_z] run summon armor_stand ~ ~ ~ {Tags:["as_part4","anvil_part","anvil_z"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":23}}],Invisible:1,DisabledSlots:4144959,Rotation:[90f]}

tag @s add as_spawned
