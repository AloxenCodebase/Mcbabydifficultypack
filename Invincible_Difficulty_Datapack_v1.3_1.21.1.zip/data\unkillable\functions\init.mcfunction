#################################################################################################################
#                                                       INIT
#################################################################################################################

scoreboard objectives add r dummy
scoreboard objectives add sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add rc minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add launchTimer dummy
scoreboard objectives add ET dummy
scoreboard objectives add onFire dummy
scoreboard objectives add onFireTick dummy
scoreboard objectives add inAir dummy
scoreboard objectives add rotateTimer dummy
scoreboard objectives add inAirDuration dummy
scoreboard objectives add underWater dummy
scoreboard objectives add oxygenLevel dummy
scoreboard objectives add dmg_taken minecraft.custom:minecraft.damage_taken
scoreboard objectives add dmg_dealt minecraft.custom:minecraft.damage_dealt
scoreboard objectives add foodLevel dummy
scoreboard objectives add hungerMessage dummy
scoreboard objectives add bed_switch dummy
scoreboard objectives add creeper_fuse dummy

scoreboard objectives add bp1 minecraft.used:minecraft.white_bed
scoreboard objectives add bp2 minecraft.used:minecraft.orange_bed
scoreboard objectives add bp3 minecraft.used:minecraft.magenta_bed
scoreboard objectives add bp4 minecraft.used:minecraft.light_blue_bed
scoreboard objectives add bp5 minecraft.used:minecraft.yellow_bed
scoreboard objectives add bp6 minecraft.used:minecraft.lime_bed
scoreboard objectives add bp7 minecraft.used:minecraft.pink_bed
scoreboard objectives add bp8 minecraft.used:minecraft.gray_bed
scoreboard objectives add bp9 minecraft.used:minecraft.light_gray_bed
scoreboard objectives add bp10 minecraft.used:minecraft.cyan_bed
scoreboard objectives add bp11 minecraft.used:minecraft.purple_bed
scoreboard objectives add bp12 minecraft.used:minecraft.blue_bed
scoreboard objectives add bp13 minecraft.used:minecraft.brown_bed
scoreboard objectives add bp14 minecraft.used:minecraft.green_bed
scoreboard objectives add bp15 minecraft.used:minecraft.red_bed
scoreboard objectives add bp16 minecraft.used:minecraft.black_bed


scoreboard objectives add trident_lt dummy
scoreboard objectives add cactus_timer dummy
scoreboard objectives add heart_x dummy
scoreboard objectives add heart_y dummy
scoreboard objectives add heart_z dummy
scoreboard objectives add fb_lt dummy
scoreboard objectives add magma_hover dummy
scoreboard objectives add dragon_message dummy
scoreboard objectives add dragon_msg_cd dummy
scoreboard objectives add enemyType dummy
scoreboard objectives add arrowTimer dummy
scoreboard objectives add mx dummy
scoreboard objectives add my dummy
scoreboard objectives add mz dummy
scoreboard objectives add constant dummy
scoreboard objectives add usedBow minecraft.used:minecraft.bow
scoreboard objectives add usedCrossbow minecraft.used:minecraft.crossbow
scoreboard objectives add anvil_timer dummy
scoreboard objectives add cur_slot dummy
scoreboard objectives add last_slot dummy
scoreboard objectives add puff_eat minecraft.used:minecraft.pufferfish
scoreboard objectives add et2_lt dummy
scoreboard objectives add notch_timer dummy
scoreboard objectives add puff_place minecraft.used:minecraft.pufferfish_bucket

scoreboard players add @a notch_timer 0
scoreboard players add @a onFire 0
scoreboard players add @a inAir 0
scoreboard players add @a inAirDuration 0
scoreboard players add @a underWater 0
scoreboard players add @a foodLevel 0
scoreboard players add @a hungerMessage 0
scoreboard players add @a launchTimer 0
scoreboard players add @a magma_hover 0
tag @s add unkillable

tellraw @a[tag=!init_msg] ["",{"text":"\n\n\n==-=-- ","color":"red","bold":true},{"text":"Minecraft but it's impossible to die - by McMakistein","color":"gold","bold":true},{"text":" --=-==","color":"red","bold":true},{"text":"\n                        [","color":"none","bold":false},{"text":"Video about this datapack","color":"dark_green","clickEvent":{"action":"open_url","value":"https://youtu.be/e8-PyqThOk4"}},{"text":"]\n\n","color":"none"},{"text":"                Follow me for more datapacks!\n","bold":true,"color":"none"},{"text":"                [","bold":false,"color":"none"},{"text":"Youtube","color":"red","bold":true,"clickEvent":{"action":"open_url","value":"https://www.youtube.com/user/McMakistein?sub_confirmation=1."},"hoverEvent":{"action":"show_text","value":{"text":"","extra":[{"text":"Subscribe for more commandblock creation like this!"}]}}},{"text":"] - [","color":"none","bold":false},{"text":"Twitter","color":"blue","bold":true,"clickEvent":{"action":"open_url","value":"https://twitter.com/MrMakistein"},"hoverEvent":{"action":"show_text","value":{"text":"","extra":[{"text":"Follow me on twitter for updates and sneakpeaks on new projects!"}]}}},{"text":"] - [","color":"none","bold":false},{"text":"Instagram","color":"gold","bold":true,"clickEvent":{"action":"open_url","value":"http://instagram.com/mrmakistein"},"hoverEvent":{"action":"show_text","value":{"text":"","extra":[{"text":"Follow me on Instagram if you want to know more about me as a person!"}]}}},{"text":"]","color":"none","bold":false}]
tag @a add init_msg

scoreboard players set minus1 constant -1
scoreboard players set 20 constant 20
scoreboard players set 60 constant 60
scoreboard players set 5 constant 5
scoreboard players set 10 constant 10
scoreboard players set 0 constant 0
gamerule logAdminCommands false
gamerule commandBlockOutput false
