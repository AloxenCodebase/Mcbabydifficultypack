scoreboard players set @s arrowTimer 5
particle firework ~ ~ ~ 0 0 0 0.1 3 force
playsound minecraft:block.slime_block.step master @a ~ ~ ~ 1.0 1.9

execute as @s store result score @s mx run data get entity @s Motion[0] 1000
execute as @s store result score @s my run data get entity @s Motion[1] 1000
execute as @s store result score @s mz run data get entity @s Motion[2] 1000

scoreboard players operation @s mx *= minus1 constant
scoreboard players operation @s my *= minus1 constant
scoreboard players operation @s mz *= minus1 constant

execute store result entity @s Motion[0] double 0.001 run scoreboard players get @s mx
execute store result entity @s Motion[1] double 0.001 run scoreboard players get @s my
execute store result entity @s Motion[2] double 0.001 run scoreboard players get @s mz
