give @s red_bed
item replace entity @s weapon.mainhand with air
