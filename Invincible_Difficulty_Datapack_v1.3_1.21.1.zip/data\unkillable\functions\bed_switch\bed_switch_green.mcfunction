give @s green_bed
item replace entity @s weapon.mainhand with air
