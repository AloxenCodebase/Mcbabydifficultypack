kill @e[type=item,nbt={Item:{id:"minecraft:iron_nugget",components:{"minecraft:custom_model_data":30}},OnGround:1b},limit=1]
kill @e[type=item,nbt={Item:{id:"minecraft:iron_nugget",components:{"minecraft:custom_model_data":31}},OnGround:1b},limit=1]
kill @e[type=item,nbt={Item:{id:"minecraft:iron_nugget",components:{"minecraft:custom_model_data":32}},OnGround:1b},limit=1]
particle firework ~ ~0.2 ~ 0.1 0.1 0.1 0.1 20 force
particle happy_villager ~ ~0.2 ~ 0.1 0.1 0.1 0.1 3 force
playsound minecraft:entity.experience_orb.pickup master @a
summon item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_model_data":1,"minecraft:custom_name":'{"text":"Notch Wings","italic":false}'}}}
