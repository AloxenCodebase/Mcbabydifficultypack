give @s cyan_bed
item replace entity @s weapon.mainhand with air
