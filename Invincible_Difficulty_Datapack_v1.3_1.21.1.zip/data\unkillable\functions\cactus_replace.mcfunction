summon armor_stand ~ ~ ~ {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute as @e[tag=cactus_init] at @s positioned ~ ~1 ~ unless entity @e[type=armor_stand,tag=cactus,distance=..0.1] if block ~ ~ ~ cactus run function unkillable:cactus_replace
execute as @e[tag=cactus_init] at @s positioned ~ ~-1 ~ unless entity @e[type=armor_stand,tag=cactus,distance=..0.1] if block ~ ~ ~ cactus run function unkillable:cactus_replace
