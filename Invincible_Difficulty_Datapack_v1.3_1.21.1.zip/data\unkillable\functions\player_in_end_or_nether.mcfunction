execute if entity @s[nbt={SelectedItem:{id:"minecraft:black_bed"}}] run function unkillable:bed_switch/bed_switch_black
execute if entity @s[nbt={SelectedItem:{id:"minecraft:blue_bed"}}] run function unkillable:bed_switch/bed_switch_blue
execute if entity @s[nbt={SelectedItem:{id:"minecraft:brown_bed"}}] run function unkillable:bed_switch/bed_switch_brown
execute if entity @s[nbt={SelectedItem:{id:"minecraft:cyan_bed"}}] run function unkillable:bed_switch/bed_switch_cyan
execute if entity @s[nbt={SelectedItem:{id:"minecraft:gray_bed"}}] run function unkillable:bed_switch/bed_switch_gray
execute if entity @s[nbt={SelectedItem:{id:"minecraft:green_bed"}}] run function unkillable:bed_switch/bed_switch_green
execute if entity @s[nbt={SelectedItem:{id:"minecraft:light_blue_bed"}}] run function unkillable:bed_switch/bed_switch_light_blue
execute if entity @s[nbt={SelectedItem:{id:"minecraft:light_gray_bed"}}] run function unkillable:bed_switch/bed_switch_light_gray
execute if entity @s[nbt={SelectedItem:{id:"minecraft:lime_bed"}}] run function unkillable:bed_switch/bed_switch_lime
execute if entity @s[nbt={SelectedItem:{id:"minecraft:magenta_bed"}}] run function unkillable:bed_switch/bed_switch_magenta
execute if entity @s[nbt={SelectedItem:{id:"minecraft:orange_bed"}}] run function unkillable:bed_switch/bed_switch_orange
execute if entity @s[nbt={SelectedItem:{id:"minecraft:pink_bed"}}] run function unkillable:bed_switch/bed_switch_pink
execute if entity @s[nbt={SelectedItem:{id:"minecraft:purple_bed"}}] run function unkillable:bed_switch/bed_switch_purple
execute if entity @s[nbt={SelectedItem:{id:"minecraft:red_bed"}}] run function unkillable:bed_switch/bed_switch_red
execute if entity @s[nbt={SelectedItem:{id:"minecraft:white_bed"}}] run function unkillable:bed_switch/bed_switch_white
execute if entity @s[nbt={SelectedItem:{id:"minecraft:yellow_bed"}}] run function unkillable:bed_switch/bed_switch_yellow

execute at @s run fill ~-4 ~-2 ~-4 ~4 ~2 ~4 air replace #minecraft:beds
