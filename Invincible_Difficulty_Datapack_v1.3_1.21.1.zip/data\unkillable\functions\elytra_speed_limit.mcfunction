clear @s firework_rocket
tellraw @a [{"text":"<","color":"white"},{"text":"POLICE","color":"blue"},{"text":"> NO FIREWORKS ALLOWED! SPEEDLIMIT OF 30 IN THIS MINECRAFT SEED!","color":"white"}]
