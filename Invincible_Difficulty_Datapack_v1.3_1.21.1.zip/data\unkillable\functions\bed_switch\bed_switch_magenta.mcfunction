give @s magenta_bed
item replace entity @s weapon.mainhand with air
