

################################################################# Wall Dmg ################################################################

tag @s remove in_vehicle
tag @s[nbt={RootVehicle:{}}] add in_vehicle

execute as @s[gamemode=survival,tag=!in_vehicle] unless block ~ ~0.6 ~ #unkillable:passable_and_air run setblock ~ ~0.6 ~ air destroy
execute as @s[gamemode=survival,tag=!in_vehicle] unless block ~ ~1 ~ #unkillable:passable_and_air run setblock ~ ~1 ~ air destroy

execute as @s[gamemode=survival,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] unless block ~ ~1 ~ #unkillable:passable_and_air run setblock ~ ~1 ~ air destroy
execute as @s[gamemode=survival,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run fill ~1 ~2 ~1 ~-1 ~2 ~-1 air destroy
execute as @s[gamemode=survival,nbt={RootVehicle:{Entity:{id:"minecraft:horse"}}}] run fill ~1 ~1 ~1 ~-1 ~2 ~-1 air destroy
execute as @s[gamemode=survival,nbt={RootVehicle:{Entity:{id:"minecraft:donkey"}}}] run fill ~1 ~1 ~1 ~-1 ~2 ~-1 air destroy

################################################################# Anvil ################################################################

execute as @e[type=falling_block,nbt={BlockState:{Name:"minecraft:anvil"}},distance=..5] run data merge entity @s {HurtEntities:0b}
execute as @e[type=falling_block,nbt={BlockState:{Name:"minecraft:damaged_anvil"}},distance=..5] run data merge entity @s {HurtEntities:0b}
execute as @e[type=falling_block,nbt={BlockState:{Name:"minecraft:chipped_anvil"}},distance=..5] run data merge entity @s {HurtEntities:0b}


################################################################# Horse levitation ################################################################

execute if entity @s[nbt={RootVehicle:{Entity:{id:"minecraft:horse"}}}] if block ~ ~-1 ~ #unkillable:passable_and_air if block ~ ~-2 ~ #unkillable:passable_and_air if block ~ ~-3 ~ #unkillable:passable_and_air run tp @s ~ ~ ~
execute if entity @s[nbt={RootVehicle:{Entity:{id:"minecraft:donkey"}}}] if block ~ ~-1 ~ #unkillable:passable_and_air if block ~ ~-2 ~ #unkillable:passable_and_air if block ~ ~-3 ~ #unkillable:passable_and_air run tp @s ~ ~ ~
execute if entity @s[nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] if block ~ ~-1 ~ #unkillable:passable_and_air if block ~ ~-2 ~ #unkillable:passable_and_air if block ~ ~-3 ~ #unkillable:passable_and_air run tp @s ~ ~ ~
execute if entity @s[nbt={RootVehicle:{Entity:{id:"minecraft:pig"}}}] if block ~ ~-1 ~ #unkillable:passable_and_air if block ~ ~-2 ~ #unkillable:passable_and_air if block ~ ~-3 ~ #unkillable:passable_and_air run tp @s ~ ~ ~

################################################################# Respawn anchor ################################################################

fill ~-6 ~-6 ~-6 ~6 ~6 ~6 respawn_anchor[charges=0] replace respawn_anchor
