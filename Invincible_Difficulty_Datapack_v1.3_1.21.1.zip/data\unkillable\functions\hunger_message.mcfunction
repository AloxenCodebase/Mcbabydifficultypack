scoreboard players add @a hungerMessage 1
scoreboard players set @a[scores={hungerMessage=6..}] hungerMessage 0
effect give @s saturation 3600 100 true

execute as @s[scores={hungerMessage=0}] run tellraw @a [{"text":"<Santa Clause> You've been a good kid, "},{"selector":"@s"},{"text":"! Here are some cookies!"}]
execute as @s[scores={hungerMessage=1}] run tellraw @a [{"text":"<"},{"selector":"@s"},{"text":"s mom","color":"white"},{"text":"> Heyy honey, you forgot your lunchbox at home. Make sure you eat enough. Love you, bye!"}]
execute as @s[scores={hungerMessage=2}] run tellraw @a [{"text":"<Claire> Hey, "},{"selector":"@s"},{"text":"! It is I, your sister! Brought you a lil snack! Enjoy!"}]
execute as @s[scores={hungerMessage=3}] run tellraw @a [{"text":"<"},{"selector":"@s"},{"text":"s grandma","color":"white"},{"text":"> You look hungry, sweetie! Here are 420kg of food!"}]
execute as @s[scores={hungerMessage=4}] run tellraw @a [{"text":"<John> I got a delivery for a \""},{"selector":"@s"},{"text":"\". You ordered pizza?"},{"text":""}]
execute as @s[scores={hungerMessage=5}] run tellraw @a [{"text":"<"},{"selector":"@s","color":"white"},{"text":"s dad"},{"text":"> Let me provide you with some nourishment, child! "}]
