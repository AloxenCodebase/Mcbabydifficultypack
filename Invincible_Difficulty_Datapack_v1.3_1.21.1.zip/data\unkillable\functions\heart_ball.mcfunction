summon armor_stand ~ ~ ~ {NoGravity:0,Tags:["heart_ball","heart_ball_init"],Invisible:1}
execute store result score @e[tag=heart_ball_init] heart_x run data get entity @s Motion[0] 1000
execute store result score @e[tag=heart_ball_init] heart_y run data get entity @s Motion[1] 1000
execute store result score @e[tag=heart_ball_init] heart_z run data get entity @s Motion[2] 1000
tag @e[type=armor_stand,tag=heart_ball_init] remove heart_ball_init
kill @s
