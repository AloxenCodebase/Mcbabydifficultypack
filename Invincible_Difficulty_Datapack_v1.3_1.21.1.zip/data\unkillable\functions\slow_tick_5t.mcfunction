execute as @a[tag=unkillable] at @s if block ~ ~1 ~ #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~0.4 ~ ~0.4 #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~0.4 ~ ~-0.4 #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~-0.4 ~ ~-0.4 #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~-0.4 ~ ~0.4 #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~0.4 ~1 ~0.4 #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~0.4 ~1 ~-0.4 #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~-0.4 ~1 ~-0.4 #unkillable:flamable run scoreboard players set @s onFire 8
execute as @a[tag=unkillable] at @s if block ~-0.4 ~1 ~0.4 #unkillable:flamable run scoreboard players set @s onFire 8

#execute as @a[tag=unkillable] at @s run fill ~-7 ~-7 ~-7 ~7 ~7 ~7 respawn_anchor[charges=0] replace respawn_anchor

schedule function unkillable:slow_tick_5t 5t
