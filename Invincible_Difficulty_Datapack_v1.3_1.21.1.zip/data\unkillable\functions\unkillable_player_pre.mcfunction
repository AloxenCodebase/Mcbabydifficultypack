
################################################################# Fire/Lava Helmet ################################################################

execute store result score @s onFireTick run data get entity @s Fire

scoreboard players remove @s[scores={onFire=1..}] onFire 1
execute if entity @s[scores={onFireTick=1..}] run scoreboard players set @s onFire 8
execute as @s at @s if block ~ ~ ~ #unkillable:flamable run scoreboard players set @s onFire 8


item replace entity @s[scores={onFire=2..}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=1]
effect give @s[scores={onFire=2..}] fire_resistance 999999 9 true
clear @s[scores={onFire=1}] minecraft:iron_nugget[custom_model_data=1]
effect clear @s[scores={onFire=1}] fire_resistance

execute as @s[scores={onFire=2..}] run particle heart ~ ~ ~ 0.5 1 0.5 1 1 force
effect give @s[scores={onFire=2..}] instant_health 1 1 true


################################################################# Levitation Helmet ################################################################

scoreboard players add @s rotateTimer 1
scoreboard players set @s[scores={rotateTimer=8..}] rotateTimer 0

execute as @s at @s unless block ~ ~-0.1 ~0.3 #unkillable:passable_and_air run scoreboard players set @s inAirDuration 0
execute as @s at @s unless block ~ ~-0.1 ~-0.3 #unkillable:passable_and_air run scoreboard players set @s inAirDuration 0
execute as @s at @s unless block ~0.3 ~-0.1 ~ #unkillable:passable_and_air run scoreboard players set @s inAirDuration 0
execute as @s at @s unless block ~-0.3 ~-0.1 ~ #unkillable:passable_and_air run scoreboard players set @s inAirDuration 0
execute as @s at @s if block ~ ~-1 ~ #unkillable:passable_and_air run scoreboard players add @s inAirDuration 1
scoreboard players set @s[scores={inAirDuration=14..}] inAir 3
execute as @s at @s if block ~ ~-1 ~ #unkillable:water run scoreboard players set @s inAirDuration 0

scoreboard players remove @s[scores={inAir=1..}] inAir 1
execute as @s at @s if block ~ ~-1 ~ #unkillable:passable_and_air if block ~ ~-2 ~ #unkillable:passable_and_air if block ~ ~-3 ~ #unkillable:passable_and_air run scoreboard players set @s inAir 15

scoreboard players set @s[scores={notch_timer=1..}] inAir 0

item replace entity @s[scores={inAir=2..,rotateTimer=0}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=2]
item replace entity @s[scores={inAir=2..,rotateTimer=1}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=3]
item replace entity @s[scores={inAir=2..,rotateTimer=2}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=4]
item replace entity @s[scores={inAir=2..,rotateTimer=3}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=5]
item replace entity @s[scores={inAir=2..,rotateTimer=4}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=6]
item replace entity @s[scores={inAir=2..,rotateTimer=5}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=7]
item replace entity @s[scores={inAir=2..,rotateTimer=6}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=8]
item replace entity @s[scores={inAir=2..,rotateTimer=7}] armor.head with iron_nugget[custom_name='{"text":"Fire Helmet","italic":false}',custom_model_data=9]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=2]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=3]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=4]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=5]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=6]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=7]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=8]
clear @s[scores={inAir=1}] minecraft:iron_nugget[custom_model_data=9]

effect give @s[scores={inAir=2..,launchTimer=0}] slow_falling 1 1 true
effect clear @s[scores={inAir=1}] slow_falling

#Launch up when in void
execute as @a[y=1,dy=-10] at @s run scoreboard players set @s launchTimer 1
execute as @a[y=10,dy=-20] at @s if block ~ 0 ~ #unkillable:passable_and_air run scoreboard players set @s launchTimer 1
execute as @s[scores={launchTimer=1..}] at @s run function unkillable:launch

################################################################# Void Launch ################################################################
execute as @a[y=10,dy=-20,nbt={RootVehicle:{}}] at @s if block ~ 0 ~ #unkillable:air run tp @s ~ ~ ~


################################################################# Water Wings ################################################################

execute store result score @s oxygenLevel run data get entity @s Air

execute as @s at @s if block ~ ~0.2 ~ #unkillable:water run scoreboard players set @s underWater 10
execute as @s at @s if block ~ ~1 ~ #unkillable:water run scoreboard players set @s underWater 10
scoreboard players remove @s[scores={underWater=1..}] underWater 1

execute as @s[scores={underWater=2..}] run function unkillable:setwings

clear @s[scores={underWater=1}] minecraft:iron_nugget[custom_model_data=10]

kill @e[type=item,nbt={Item:{id:"minecraft:iron_nugget",components:{"minecraft:custom_model_data":10}}}]

execute as @s[scores={oxygenLevel=..295,underWater=1..}] at @s run tp @s ~ ~0.1 ~
execute as @s[scores={oxygenLevel=..290,underWater=1..}] at @s run tp @s ~ ~0.2 ~
execute as @s[scores={oxygenLevel=..285,underWater=1..}] at @s run tp @s ~ ~0.2 ~
execute as @s[scores={oxygenLevel=..280,underWater=1..}] at @s run tp @s ~ ~0.2 ~
execute as @s[scores={oxygenLevel=..275,underWater=1..}] at @s run tp @s ~ ~0.2 ~
execute as @s[scores={oxygenLevel=..270,underWater=1..}] at @s run tp @s ~ ~0.2 ~

execute as @s[scores={underWater=1..}] at @s if block ~ ~ ~ bubble_column if block ~ ~-2 ~ magma_block run setblock ~ ~-2 ~ water destroy
execute as @s[scores={underWater=1..}] at @s if block ~ ~ ~ bubble_column if block ~ ~-2 ~ magma_block run setblock ~ ~-2 ~ water destroy

execute as @s[scores={oxygenLevel=..299,underWater=1..,dmg_taken=1..}] at @s unless block ~ ~1 ~ #unkillable:water run fill ~1 ~1 ~1 ~-1 ~1 ~-1 air destroy
execute as @s[scores={oxygenLevel=..299,underWater=1..,dmg_taken=1..}] at @s unless block ~ ~2 ~ #unkillable:water run fill ~1 ~2 ~1 ~-1 ~2 ~-1 air destroy



################################################################# Hunger ################################################################

execute store result score @s foodLevel run data get entity @s foodLevel
execute as @s[scores={foodLevel=..19}] run function unkillable:hunger_message

################################################################# Elytra Speedlimit ################################################################

execute as @s[nbt={Inventory:[{id:"minecraft:elytra",slot:102},{id:"minecraft:firework_rocket"}]}] at @s run function unkillable:elytra_speed_limit


################################################################# Potions ################################################################
execute as @e[type=potion,distance=..3] at @s run data merge entity @s {Item:{id:"minecraft:splash_potion",components:{"minecraft:potion_contents":{potion:"minecraft:strong_healing"}}}}
execute if entity @s[nbt={SelectedItem:{id:"minecraft:potion"}}] unless entity @s[nbt={SelectedItem:{id:"minecraft:potion",components:{"minecraft:potion_contents":{potion:"minecraft:strong_healing"}}}}] at @s run item replace entity @s weapon.mainhand with potion[potion_contents={potion:"strong_healing"}]

################################################################# Enderpearl ################################################################

execute if entity @e[type=ender_pearl,distance=..5] run effect give @s resistance 8 98 true
execute if entity @s[nbt={HurtTime:8s,ActiveEffects:[{id:"minecraft:resistance",amplifier:98}]}] run effect give @s resistance 8 98 true


################################################################# Beds ################################################################

execute if entity @s[nbt={Dimension:"minecraft:the_end"}] run function unkillable:player_in_end_or_nether
execute if entity @s[nbt={Dimension:"minecraft:the_nether"}] run function unkillable:player_in_end_or_nether


################################################################# Trident ################################################################
scoreboard players add @e[type=trident,distance=..5] trident_lt 0
scoreboard players set @e[type=trident,distance=..5,scores={trident_lt=0}] trident_lt 1
execute as @e[type=trident,scores={trident_lt=70..},distance=..4] at @s run playsound minecraft:block.fire.extinguish master @a
execute as @e[type=trident,scores={trident_lt=70..},distance=..4] at @s run particle large_smoke ~ ~ ~ 0.1 0.2 0.1 0.1 5 force
kill @e[type=trident,scores={trident_lt=70..},distance=..4]

################################################################# Iron Golem ################################################################

execute as @e[type=iron_golem,distance=..50] run data merge entity @s {PlayerCreated:1b}
execute as @s[scores={dmg_dealt=1..}] at @s if entity @e[type=iron_golem,nbt={HurtTime:10s},distance=..10] run tellraw @a {"text":"<Iron Golem> :("}


################################################################# Tnt ################################################################

execute as @e[type=tnt,nbt={Fuse:5s},distance=..20] at @s run setblock ~ ~ ~ tnt
execute as @e[type=tnt,nbt={Fuse:5s},distance=..20] at @s run kill @s


################################################################# Berries ################################################################

fill ~-2 ~-1 ~-2 ~2 ~1 ~2 dead_bush replace minecraft:sweet_berry_bush

################################################################# Cactus ################################################################

execute positioned ~ ~-0.9 ~ if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~ ~-2 ~ if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}

execute positioned ~ ~ ~1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~ ~ ~-1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~-1 ~ ~ if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~1 ~ ~ if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}

execute positioned ~ ~1 ~1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~ ~1 ~-1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~-1 ~1 ~ if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~1 ~1 ~ if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}

execute positioned ~1 ~ ~1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~-1 ~ ~-1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~-1 ~ ~1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}
execute positioned ~1 ~ ~-1 if block ~ ~ ~ cactus align xyz run summon armor_stand ~0.5 ~0.5 ~0.5 {NoGravity:1,Tags:["cactus","cactus_init"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}],Marker:1,Invisible:1}

################################################################# Fireworks ################################################################

execute at @e[type=firework_rocket,distance=..5] at @s run function unkillable:firework_spread

################################################################# Magma ################################################################
tag @s remove magma_hover
execute as @s at @s if block ~ ~-1 ~ magma_block run tag @s add magma_hover
execute as @s at @s if block ~ ~-2 ~ magma_block run tag @s add magma_hover

execute as @s at @s if block ~ ~-1 ~0.3 magma_block run tag @s add magma_hover
execute as @s at @s if block ~0.3 ~-1 ~ magma_block run tag @s add magma_hover
execute as @s at @s if block ~-0.3 ~-1 ~ magma_block run tag @s add magma_hover
execute as @s at @s if block ~ ~-1 ~-0.3 magma_block run tag @s add magma_hover

scoreboard players remove @s[scores={magma_hover=1..}] magma_hover 1
scoreboard players set @e[tag=magma_hover] magma_hover 2
execute as @s[tag=magma_hover] at @s run particle lava ~ ~0.1 ~ 0.2 0 0.2 0.01 1 force
execute as @s[tag=magma_hover] at @s run particle cloud ~ ~0.1 ~ 0.2 0 0.2 0.01 1 force
execute as @s[tag=magma_hover] at @s run particle flame ~ ~0.1 ~ 0.2 0 0.2 0.01 1 force
effect give @s[tag=magma_hover] minecraft:levitation 1 255 true
execute as @s[tag=magma_hover] at @s unless block ~ ~-0.2 ~ #unkillable:passable_and_air run tp @s ~ ~0.05 ~
effect clear @s[scores={magma_hover=1}] minecraft:levitation


################################################################# Dragon ################################################################

kill @e[type=minecraft:dragon_fireball]
execute if entity @e[type=ender_dragon,distance=30..40] run scoreboard players set @s dragon_message 0
execute if entity @e[type=ender_dragon,distance=..20] run scoreboard players add @s dragon_message 1

execute as @s[scores={dragon_message=1}] at @s run tellraw @a {"text":"Enderdragon is having technical difficulties"}
scoreboard players set @s[scores={dragon_message=1}] dragon_message 2

################################################################# Endcrystal ################################################################

tag @e[type=end_crystal,distance=..6] add crystal_kill


################################################################# Mobs ################################################################

kill @e[scores={enemyType=1},distance=..1.8]
kill @e[type=ravager,distance=..4.5]
kill @e[type=blaze,distance=..2.5]
execute as @e[scores={enemyType=1},distance=..3.7] run data merge entity @s {Motion:[0.0,2.0,0.0]}
execute as @e[type=ravager,distance=..6] run data merge entity @s {Motion:[0.0,2.0,0.0]}


################################################################# Blazes and Shulkers ################################################################


execute as @e[tag=proj_to_kill,distance=..3] at @s run particle firework ~ ~ ~ 0 0 0 0.1 5 force
execute as @e[tag=proj_to_kill,distance=..3] at @s run playsound minecraft:block.beehive.exit master @a
execute as @e[tag=proj_to_kill,distance=..3] at @s run kill @s

################################################################# Arrow deflect ################################################################

tag @e[type=arrow] add arrow
tag @e[type=spectral_arrow] add arrow

execute if entity @s[scores={usedBow=1..}] run scoreboard players set @e[tag=arrow,distance=..2] arrowTimer 10
execute if entity @s[scores={usedCrossbow=1..}] run scoreboard players set @e[tag=arrow,distance=..2] arrowTimer 10
execute as @e[tag=arrow,distance=..3.5,scores={arrowTimer=0},nbt={inGround:0b}] at @s run function unkillable:arrow_def

execute as @e[tag=arrow,distance=..3] run data merge entity @s {damage:0.0d}
execute as @e[tag=arrow,distance=3..4] run data merge entity @s {damage:2.0d}


################################################################# Guardians ################################################################

tag @e[type=guardian,distance=..15] add g_exp
tag @e[type=elder_guardian,distance=..15] add g_exp

execute as @e[tag=g_exp] at @s run particle smoke ~ ~ ~ 0.3 0.3 0.3 0.1 10 force
execute as @e[tag=g_exp] at @s run particle bubble ~ ~ ~ 0.3 0.3 0.3 0.1 40 force
execute as @e[tag=g_exp] at @s run data merge entity @s {DeathTime:19,Health:0.0f}

################################################################# Pufferfish ################################################################

execute as @s[scores={puff_eat=1..}] at @s run effect clear @s nausea
execute as @s[scores={puff_eat=1..}] at @s run effect clear @s poison
execute as @s[scores={puff_eat=1..}] at @s run effect give @s luck 60 1 false
execute as @s[scores={puff_eat=1..}] at @s run particle block gold_block ~ ~ ~ 0.5 1 0.5 0.1 30 force
execute as @s[scores={puff_eat=1..}] at @s run particle firework ~ ~ ~ 0.5 1 0.5 0.1 10 force
execute as @s[scores={puff_eat=1..}] at @s run playsound minecraft:entity.puffer_fish.blow_up master @a ~ ~ ~ 1.0 1.0
execute as @s[scores={puff_eat=1..}] at @s run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 0.5 1.0


execute if entity @s[scores={puff_place=1..}] run tellraw @s {"text":"<Pufferfish> Not feeling it today, sorry! I'm staying in by bucket!"}
execute if entity @s[scores={puff_place=1..}] run execute as @e[type=pufferfish,distance=..5,limit=1] at @s run data merge entity @s {DeathTime:19,Health:0.0f}
execute if entity @s[scores={puff_place=1..}] run effect give @s instant_health 1 1 true
execute if entity @s[scores={puff_place=1..}] run item replace entity @s weapon.mainhand with minecraft:pufferfish_bucket

################################################################# Witherrose ################################################################

execute if block ~ ~ ~ wither_rose run effect give @s instant_health 1 1 true
fill ~1 ~1 ~1 ~-1 ~-1 ~-1 poppy replace wither_rose

################################################################# Evokers ################################################################


execute as @e[type=evoker_fangs,distance=..3] at @s run data merge entity @s {Warmup:-8}



################################################################# Dispenser ################################################################

fill ~1 ~-1 ~-1 ~4 ~1 ~1 dispenser[facing=east] replace dispenser[facing=west]
fill ~-1 ~-1 ~-1 ~-4 ~1 ~1 dispenser[facing=west] replace dispenser[facing=east]
fill ~-1 ~-1 ~-1 ~1 ~1 ~-4 dispenser[facing=north] replace dispenser[facing=south]
fill ~-1 ~-1 ~1 ~1 ~1 ~4 dispenser[facing=south] replace dispenser[facing=north]
fill ~-1 ~1 ~-1 ~1 ~4 ~1 dispenser[facing=up] replace dispenser[facing=down]
fill ~-1 ~-1 ~-1 ~1 ~-4 ~1 dispenser[facing=down] replace dispenser[facing=up]


################################################################# Flying mobs ################################################################

scoreboard players set @e[scores={enemyType=2},distance=..4] et2_lt 1
execute as @e[scores={enemyType=2,et2_lt=1..},distance=..4] at @s run particle smoke ~ ~0.5 ~ 0 0 0 0.1 10 force
execute as @e[type=phantom,scores={et2_lt=1..},distance=..4] at @s run summon item ~ ~0.2 ~ {Item:{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_name":'{"text":"Phantom Wing","bold":false,"italic":false}',"minecraft:custom_model_data":30}}}
execute as @e[type=bee,scores={et2_lt=1..},distance=..4] at @s run summon item ~ ~0.2 ~ {Item:{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_name":'{"text":"Bee Wing","bold":false,"italic":false}',"minecraft:custom_model_data":31}}}
execute as @e[type=vex,scores={et2_lt=1..},distance=..4] at @s run summon item ~ ~0.2 ~ {Item:{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_name":'{"text":"Vex Wing","bold":false,"italic":false}',"minecraft:custom_model_data":32}}}

execute as @e[scores={enemyType=2,et2_lt=1..},distance=..4] at @s run kill @s

################################################################# Llama spit ################################################################

kill @e[type=llama_spit,distance=..5]

################################################################# Enchantment ################################################################

tag @s[nbt={Inventory:[{id:"minecraft:enchanted_book",components:{"minecraft:stored_enchantments":{levels:{"minecraft:channeling":1}}}}]}] add has_c_book
execute as @s[tag=has_c_book] at @s run summon item ~ ~ ~ {Tags:[c_book_item],PickupDelay:99999,Item:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{levels:{"minecraft:channeling":1}}}}}
execute as @s[tag=has_c_book] at @s run tellraw @a [{"text":"<","color":"white"},{"text":"FBI","color":"blue"},{"text":"> This is forbidden knowledge!","color":"white"}]

execute as @s[tag=has_c_book] at @s run clear @s enchanted_book[stored_enchantments={channeling:1..}]
tag @s[tag=has_c_book] remove has_c_book

tag @s[nbt={Inventory:[{id:"minecraft:enchanted_book",components:{"minecraft:stored_enchantments":{levels:{"minecraft:thorns":1}}}}]}] add has_t_book
execute as @s[tag=has_t_book] at @s run summon item ~ ~ ~ {Tags:[t_book_item],PickupDelay:99999,Item:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{levels:{"minecraft:thorns":1}}}}}
execute as @s[tag=has_t_book] at @s run tellraw @a [{"text":"<","color":"white"},{"text":"FBI","color":"blue"},{"text":"> This is forbidden knowledge!","color":"white"}]

execute as @s[tag=has_t_book] at @s run clear @s enchanted_book[stored_enchantments={thorns:1..}]
tag @s[tag=has_t_book] remove has_t_book

tag @s[nbt={Inventory:[{id:"minecraft:enchanted_book",components:{"minecraft:stored_enchantments":{levels:{"minecraft:riptide":1}}}}]}] add has_r_book
execute as @s[tag=has_r_book] at @s run summon item ~ ~ ~ {Tags:[t_book_item],PickupDelay:99999,Item:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{levels:{"minecraft:riptide":1}}}}}
execute as @s[tag=has_r_book] at @s run tellraw @a [{"text":"<","color":"white"},{"text":"FBI","color":"blue"},{"text":"> This is forbidden knowledge!","color":"white"}]

execute as @s[tag=has_r_book] at @s run clear @s enchanted_book[stored_enchantments={riptide:1..}]
tag @s[tag=has_r_book] remove has_r_book

################################################################# Campfires ################################################################
execute if block ~ ~ ~ soul_campfire run effect give @s instant_health 1 1 true
execute if block ~ ~ ~ campfire run effect give @s instant_health 1 1 true
fill ~-1 ~-1 ~-1 ~1 ~1 ~1 soul_campfire[lit=false] replace soul_campfire[lit=true]
fill ~-1 ~-1 ~-1 ~1 ~1 ~1 campfire[lit=false] replace campfire[lit=true]

################################################################# Notch Wings ################################################################

execute if entity @s[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",components:{"minecraft:custom_model_data":1}}},scores={notch_timer=0,rc=1..}] run scoreboard players set @s notch_timer 1
execute if entity @s[scores={notch_timer=1..}] as @s run function unkillable:notch_wing

################################################################# Drowned Tridents ################################################################

execute as @e[type=drowned] at @s run data merge entity @s {HandItems:[{},{}]}




#
