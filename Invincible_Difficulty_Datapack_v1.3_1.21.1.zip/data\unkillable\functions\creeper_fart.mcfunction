summon area_effect_cloud ~ ~ ~ {Tags:["r","r1"]}
summon area_effect_cloud ~ ~ ~ {Tags:["r","r2"]}
summon area_effect_cloud ~ ~ ~ {Tags:["r","r3"]}
summon area_effect_cloud ~ ~ ~ {Tags:["r","r4"]}
scoreboard players set @e[tag=r,sort=random,limit=1] r 1
execute as @e[tag=r1,scores={r=1}] at @s run playsound minecraft:m_fart1 master @a ~ ~ ~ 0.7 1.0
execute as @e[tag=r2,scores={r=1}] at @s run playsound minecraft:m_fart2 master @a ~ ~ ~ 0.7 1.0
execute as @e[tag=r3,scores={r=1}] at @s run playsound minecraft:m_fart3 master @a ~ ~ ~ 0.7 1.0
execute as @e[tag=r4,scores={r=1}] at @s run playsound minecraft:m_fart4 master @a ~ ~ ~ 0.7 1.0
kill @e[tag=r]

particle minecraft:dust 0.2 1.0 0.2 2 ~ ~0.7 ~ 0.3 0.7 0.3 0.1 10
particle minecraft:dust 0.0 0.7 0.0 2 ~ ~0.7 ~ 0.4 0.7 0.4 0.1 15
