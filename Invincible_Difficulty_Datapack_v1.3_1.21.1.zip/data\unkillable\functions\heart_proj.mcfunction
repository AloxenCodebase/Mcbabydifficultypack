
execute store result entity @s Motion[0] double 0.007 run scoreboard players get @s heart_x
execute store result entity @s Motion[1] double 0.007 run scoreboard players get @s heart_y
execute store result entity @s Motion[2] double 0.007 run scoreboard players get @s heart_z

particle heart ~ ~ ~ 0 0 0 0.1 5 force


execute unless block ~ ~-1 ~ #unkillable:passable_and_air run summon area_effect_cloud ~ ~ ~ {Tags:[heart_explosion]}
execute as @e[type=area_effect_cloud,tag=heart_explosion] at @s run playsound minecraft:entity.dragon_fireball.explode master @a ~ ~ ~ 0.8 1
execute as @e[type=area_effect_cloud,tag=heart_explosion] at @s run playsound minecraft:entity.splash_potion.break master @a ~ ~ ~ 0.7 1
execute as @e[type=area_effect_cloud,tag=heart_explosion] at @s run effect give @a[distance=..4] instant_health 1 9 true
execute as @e[type=area_effect_cloud,tag=heart_explosion] at @s run particle cloud ~ ~ ~ 1 1 1 0.1 20 force
execute as @e[type=area_effect_cloud,tag=heart_explosion] at @s run particle heart ~ ~ ~ 2 1 2 0.1 30 force
execute at @e[type=area_effect_cloud,tag=heart_explosion] run kill @s
