give @s brown_bed
item replace entity @s weapon.mainhand with air
