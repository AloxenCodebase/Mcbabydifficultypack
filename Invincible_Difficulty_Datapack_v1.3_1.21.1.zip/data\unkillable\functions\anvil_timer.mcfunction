scoreboard players add @s anvil_timer 1
execute as @s[scores={anvil_timer=1..4}] at @s run setblock ~ ~ ~ air

kill @s[scores={anvil_timer=100..}]
