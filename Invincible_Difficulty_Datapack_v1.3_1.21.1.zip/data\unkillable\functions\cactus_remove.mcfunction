scoreboard players set @s cactus_timer 100
execute as @s at @s positioned ~ ~1 ~ as @e[type=armor_stand,tag=cactus,distance=..0.1,scores={cactus_timer=11}] at @s if block ~ ~ ~ barrier run function unkillable:cactus_remove
execute as @s at @s positioned ~ ~-1 ~ as @e[type=armor_stand,tag=cactus,distance=..0.1,scores={cactus_timer=11}] at @s if block ~ ~ ~ barrier run function unkillable:cactus_remove
