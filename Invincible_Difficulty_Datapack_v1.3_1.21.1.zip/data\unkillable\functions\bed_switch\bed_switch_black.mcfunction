give @s black_bed
item replace entity @s weapon.mainhand with air
