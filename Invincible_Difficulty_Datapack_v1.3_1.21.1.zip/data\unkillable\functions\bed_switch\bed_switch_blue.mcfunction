give @s blue_bed
item replace entity @s weapon.mainhand with air
