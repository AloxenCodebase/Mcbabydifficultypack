give @s lime_bed
item replace entity @s weapon.mainhand with air
