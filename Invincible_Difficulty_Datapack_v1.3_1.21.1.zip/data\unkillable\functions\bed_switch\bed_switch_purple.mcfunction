give @s purple_bed
item replace entity @s weapon.mainhand with air
