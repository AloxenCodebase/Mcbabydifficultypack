give @s orange_bed
item replace entity @s weapon.mainhand with air
