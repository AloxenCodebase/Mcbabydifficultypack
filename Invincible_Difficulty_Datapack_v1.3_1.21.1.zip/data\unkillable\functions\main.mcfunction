#####################################################################################################
#                                                                                                   #
#                                      Unkillable by McMakistein                                    #
#                                                                                                   #
#####################################################################################################

########################################################################################## INIT #######################################################################################################

execute as @a[tag=!unkillable_init] at @s run function unkillable:init
tag @a add unkillable_init

################################################################# General ################################################################

tag @e[type=small_fireball] add proj_to_kill
tag @e[type=shulker_bullet] add proj_to_kill

execute as @a[tag=unkillable] at @s run function unkillable:unkillable_player_pre
gamerule maxEntityCramming 0

################################################################# Wither ################################################################

execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:210}] run tellraw @a {"text":"<Left Wither Head> Aight bois, Ima take the lead on this one"}
execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:150}] run tellraw @a {"text":"<Right Wither Head> Hell nah! My turn today!"}
execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:85}] run tellraw @a {"text":"<Left Wither Head> Oh shut up..."}
execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:65}] run tellraw @a {"text":"<Left Wither Head> idiot"}
execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:30}] run tellraw @a {"text":"<Middle Wither Head> I quit! I just can't with you, babies..."}
execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:1}] run tellraw @a {"text":"Wither left the game","color":"yellow"}
execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:1}] run data merge entity @s {Health:0.0f,DeathTime:19}

execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:0},distance=..100] run tellraw @a {"text":"Wither left the game","color":"yellow"}
execute if entity @a[tag=unkillable] run execute as @e[type=wither,nbt={Invul:0},distance=..100] run data merge entity @s {Health:0.0f,DeathTime:19}

################################################################# Trident ################################################################

scoreboard players add @e[type=trident,scores={trident_lt=1..}] trident_lt 1


################################################################# Creeper Fart cloud ################################################################

scoreboard players add @e[type=creeper] creeper_fuse 0
execute as @e[type=creeper] at @s unless entity @a[tag=unkillable,distance=..7] run scoreboard players set @s creeper_fuse 0
execute as @e[type=creeper,scores={creeper_fuse=0}] at @s if entity @a[tag=unkillable,distance=..4] run scoreboard players set @s creeper_fuse 1
execute as @e[type=creeper,scores={creeper_fuse=1..9}] at @s if entity @a[tag=unkillable,distance=..1] run scoreboard players set @s creeper_fuse 10
scoreboard players add @e[type=creeper,scores={creeper_fuse=1..}] creeper_fuse 1

execute as @e[type=creeper,scores={creeper_fuse=22..}] at @s run function unkillable:creeper_fart
execute as @e[type=creeper,scores={creeper_fuse=22..}] at @s run data merge entity @s {DeathTime:19,Health:0.0f}

################################################################# Cactus ################################################################

execute as @e[tag=cactus_init] at @s positioned ~ ~1 ~ unless entity @e[type=armor_stand,tag=cactus,distance=..0.1] if block ~ ~ ~ cactus run function unkillable:cactus_replace
execute as @e[tag=cactus_init] at @s positioned ~ ~-1 ~ unless entity @e[type=armor_stand,tag=cactus,distance=..0.1] if block ~ ~ ~ cactus run function unkillable:cactus_replace


execute as @e[type=armor_stand,tag=cactus_init] at @s run setblock ~ ~ ~ barrier
scoreboard players set @e[type=armor_stand,tag=cactus_init] cactus_timer 1
tag @e[type=armor_stand,tag=cactus_init] remove cactus_init

scoreboard players add @e[type=armor_stand,tag=cactus,scores={cactus_timer=1..10}] cactus_timer 1
scoreboard players add @e[type=armor_stand,tag=cactus,scores={cactus_timer=100..}] cactus_timer 1

execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=2}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":12}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=3}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":13}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=4}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":14}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=5}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":15}}]}

execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=104}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":15}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=105}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":14}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=106}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":13}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=107}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":12}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=108}] run data merge entity @s {ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":11}}]}
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=109}] at @s run setblock ~ ~ ~ cactus
execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=109}] at @s run kill @s

execute as @e[type=armor_stand,tag=cactus,scores={cactus_timer=11}] at @s unless entity @a[distance=..5] run function unkillable:cactus_remove



################################################################# Ghast ################################################################

scoreboard players add @e[type=fireball] fb_lt 1
execute as @e[type=ghast] at @s if entity @a[tag=unkillable,distance=..200] run execute as @e[type=fireball,scores={fb_lt=2},distance=..10] at @s run function unkillable:heart_ball

execute as @e[tag=heart_ball] at @s run function unkillable:heart_proj

################################################################# Dragon ################################################################

execute as @e[type=ender_dragon] at @s run data merge entity @s {NoAI:0b}
execute as @e[type=ender_dragon] at @s if entity @a[tag=unkillable,distance=..20] run data merge entity @s {NoAI:1b}

################################################################# Crystal ################################################################

execute as @e[type=arrow] at @s run tag @e[type=end_crystal,distance=..4] add crystal_kill
execute as @e[type=snowball] at @s run tag @e[type=end_crystal,distance=..4] add crystal_kill
execute as @e[type=trident] at @s run tag @e[type=end_crystal,distance=..4] add crystal_kill

execute as @e[tag=crystal_kill] at @s run particle block glass ~ ~1 ~ 0.5 0.5 0.5 0.1 40 force
execute as @e[tag=crystal_kill] at @s run playsound minecraft:block.glass.break master @a ~ ~ ~ 1.0 1.0
execute as @e[tag=crystal_kill] at @s run playsound minecraft:block.crop.break master @a
execute as @e[tag=crystal_kill] at @s run particle explosion ~ ~1 ~ 0.5 0.5 0.5 0.1 2 force
execute as @e[tag=crystal_kill] at @s run particle large_smoke ~ ~1 ~ 0.3 0.3 0.3 0.1 20 force
execute as @e[tag=crystal_kill] at @s run summon armor_stand ~ ~0.8 ~ {Tags:["crystal_part","cp1"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":16}}],Invisible:1,Motion:[0.26,0.15,-0.07]}
execute as @e[tag=crystal_kill] at @s run summon armor_stand ~ ~0.8 ~ {Tags:["crystal_part","cp1"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":16}}],Invisible:1,Motion:[-0.13,0.25,0.06],Rotation:[160f]}
execute as @e[tag=crystal_kill] at @s run summon armor_stand ~ ~0.9 ~ {Tags:["crystal_part","cp1"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":17}}],Invisible:1,Motion:[0.18,0.05,-0.22],Rotation:[90f]}
execute as @e[tag=crystal_kill] at @s run summon armor_stand ~ ~0.8 ~ {Tags:["crystal_part","cp2"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":18}}],Invisible:1,Motion:[0.02,0.08,0.29],Rotation:[190f]}
execute as @e[tag=crystal_kill] at @s run summon armor_stand ~ ~0.9 ~ {Tags:["crystal_part","cp2"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":19}}],Invisible:1,Motion:[-0.15,0.13,0.06],Rotation:[20f]}
execute as @e[tag=crystal_kill] at @s run summon armor_stand ~ ~0.9 ~ {Tags:["crystal_part","cp2"],ArmorItems:[{},{},{},{id:"minecraft:iron_nugget",count:1,components:{"minecraft:custom_model_data":19}}],Invisible:1,Motion:[-0.05,0.13,-0.31],Rotation:[220f]}

execute as @e[tag=crystal_kill] at @s run kill @s

execute as @e[tag=crystal_part] at @s run function unkillable:crystal_part

################################################################# Arrow ################################################################

scoreboard players add @e[type=arrow] arrowTimer 0
scoreboard players remove @e[type=arrow,scores={arrowTimer=1..}] arrowTimer 1


################################################################# Anvil ################################################################


execute as @e[type=falling_block,tag=!as_spawned,nbt={BlockState:{Name:"minecraft:anvil"}}] at @s if entity @a[tag=unkillable,distance=..10] unless block ~ ~-0.5 ~ #unkillable:passable_and_air run function unkillable:spawn_anvil_parts
execute as @e[type=falling_block,tag=!as_spawned,nbt={BlockState:{Name:"minecraft:chipped_anvil"}}] at @s if entity @a[tag=unkillable,distance=..10] unless block ~ ~-0.5 ~ #unkillable:passable_and_air run function unkillable:spawn_anvil_parts
execute as @e[type=falling_block,tag=!as_spawned,nbt={BlockState:{Name:"minecraft:damaged_anvil"}}] at @s if entity @a[tag=unkillable,distance=..10] unless block ~ ~-0.5 ~ #unkillable:passable_and_air run function unkillable:spawn_anvil_parts

execute as @e[tag=as_center] at @s run function unkillable:anvil_timer
execute as @e[tag=anvil_part] at @s run function unkillable:anvil_part_timer

################################################################# Potions ################################################################

execute as @e[type=potion] at @s if entity @a[tag=unkillable,distance=..10] run particle heart ~ ~ ~ 0 0 0 0.1 1 force


################################################################# Tnt Minecart ################################################################
tag @e[type=tnt_minecart] add tnt_mc_exp
execute as @e[tag=tnt_mc_exp] at @s run summon minecart ~ ~ ~
execute as @e[tag=tnt_mc_exp] at @s run summon tnt ~ ~ ~ {Fuse:79,Motion:[0.0,1.0,0.0]}
execute as @e[tag=tnt_mc_exp] at @s run kill @s


##################################################################################### Enchantments ###########################################################################################################

execute as @e[tag=c_book_item] at @s run particle smoke ~ ~0.3 ~ 0.1 0.1 0.1 0.05 1 force
execute as @e[tag=t_book_item] at @s run particle smoke ~ ~0.3 ~ 0.1 0.1 0.1 0.05 1 force




########################################################################################### Notch Wing #####################################################################################################


# CHEATER! Snooping around in my datapack like that, smh...
# Shoulda tried finding this item legitimately ^^

execute as @e[type=item,nbt={Item:{id:"minecraft:iron_nugget",components:{"minecraft:custom_model_data":30}},OnGround:1b}] at @s run execute as @e[type=item,nbt={Item:{id:"minecraft:iron_nugget",components:{"minecraft:custom_model_data":31}},OnGround:1b},distance=..1] at @s run execute as @e[type=item,nbt={Item:{id:"minecraft:iron_nugget",components:{"minecraft:custom_model_data":32}},OnGround:1b},distance=..1] at @s run function unkillable:summon_wing

################################################################################################# Enderpearl ###############################################################################################

execute as @e[type=ender_pearl] at @s if entity @a[tag=unkillable,distance=..50] run particle heart ~ ~ ~ 0 0 0 0.1 1 force
execute as @e[type=ender_pearl] at @s if entity @a[tag=unkillable,distance=..50] run particle smoke ~ ~ ~ 0 0 0 0.05 1 force

################################################################################################################################################################################################


execute as @a[tag=unkillable] at @s run function unkillable:unkillable_player_post

effect give @e[tag=invis] invisibility 1 1 true
scoreboard players set @a rc 0
scoreboard players set @a sneak 0
scoreboard players set @a dmg_taken 0
scoreboard players set @a usedBow 0
scoreboard players set @a usedCrossbow 0
scoreboard players set @a dmg_dealt 0
scoreboard players set @a puff_eat 0
scoreboard players set @a puff_place 0

#
