#################################################################################################################
#                                                       ENTITYTYPE
#################################################################################################################

scoreboard players set @e[type=zombie] enemyType 1
scoreboard players set @e[type=zombie_villager] enemyType 1
scoreboard players set @e[type=zombie_horse] enemyType 1
scoreboard players set @e[type=zombified_piglin] enemyType 1
scoreboard players set @e[type=wither_skeleton] enemyType 1
scoreboard players set @e[type=panda] enemyType 1
scoreboard players set @e[type=husk] enemyType 1
scoreboard players set @e[type=skeleton] enemyType 1
scoreboard players set @e[type=stray] enemyType 1
scoreboard players set @e[type=endermite] enemyType 1
scoreboard players set @e[type=enderman] enemyType 1
scoreboard players set @e[type=wolf] enemyType 1
scoreboard players set @e[type=hoglin] enemyType 1
scoreboard players set @e[type=magma_cube] enemyType 1
scoreboard players set @e[type=drowned] enemyType 1
scoreboard players set @e[type=evoker] enemyType 1
scoreboard players set @e[type=illusioner] enemyType 1
scoreboard players set @e[type=dolphin] enemyType 1
scoreboard players set @e[type=mooshroom] enemyType 1
scoreboard players set @e[type=piglin] enemyType 1
scoreboard players set @e[type=piglin_brute] enemyType 1
scoreboard players set @e[type=pillager] enemyType 1
scoreboard players set @e[type=ravager] enemyType 1
scoreboard players set @e[type=silverfish] enemyType 1
scoreboard players set @e[type=slime] enemyType 1
scoreboard players set @e[type=spider] enemyType 1
scoreboard players set @e[type=cave_spider] enemyType 1
scoreboard players set @e[type=vindicator] enemyType 1
scoreboard players set @e[type=wither_skeleton] enemyType 1
scoreboard players set @e[type=zoglin] enemyType 1
scoreboard players set @e[type=zombie_horse] enemyType 1
scoreboard players set @e[type=skeleton_horse] enemyType 1
scoreboard players set @e[type=polar_bear] enemyType 1
scoreboard players set @e[type=giant] enemyType 1
scoreboard players set @e[type=snow_golem] enemyType 1
scoreboard players set @e[type=pufferfish] enemyType 1


scoreboard players set @e[type=breeze] enemyType 1
scoreboard players set @e[type=bogged] enemyType 1
scoreboard players set @e[type=armadillo] enemyType 1

scoreboard players set @e[type=phantom] enemyType 2
scoreboard players set @e[type=vex] enemyType 2
scoreboard players set @e[type=bee] enemyType 2
scoreboard players set @e[type=creeper] enemyType 0
scoreboard players set @e[type=wither] enemyType 0
scoreboard players set @e[type=ender_dragon] enemyType 0
scoreboard players set @e[type=iron_golem] enemyType 0
