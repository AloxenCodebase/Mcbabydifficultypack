give @s light_blue_bed
item replace entity @s weapon.mainhand with air
